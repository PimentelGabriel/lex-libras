# GlosaGenerator

1- Insert next to the file "glosaGenerator.py" a text.txt file containing the sentences that will be translated into gloss, separated by line. Each line must contain a sentence.

2- Run the command python3 glosaGenerator.py or python glosaGenerator.py at the terminal.

3- The glosses of the sentences will be generated and stored in a glosses.txt file.

Contribution: Luana Silva Reis
